import React from 'react';

const Profile = () => {
  return (
    <div>
      <p>this is Profile</p>
    </div>
  );
};

export default Profile;
